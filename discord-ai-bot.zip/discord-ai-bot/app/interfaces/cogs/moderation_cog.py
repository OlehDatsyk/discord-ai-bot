"""Moderation commands: AI-assisted content checking and basic mod tools."""
from __future__ import annotations

import logging

import discord
from discord import app_commands
from discord.ext import commands

from app.container import ServiceContainer

logger = logging.getLogger(__name__)


class ModerationCog(commands.Cog):
    def __init__(self, container: ServiceContainer) -> None:
        self.container = container

    @app_commands.command(name="moderate", description="Check text against OpenAI's moderation categories.")
    @app_commands.describe(text="The text to check.")
    @app_commands.checks.has_permissions(manage_messages=True)
    async def moderate(self, interaction: discord.Interaction, text: str) -> None:
        await interaction.response.defer(thinking=True, ephemeral=True)
        try:
            result = await self.container.moderation_service.check_message(
                text,
                guild_id=str(interaction.guild_id or "dm"),
                channel_id=str(interaction.channel_id),
                user_id=str(interaction.user.id),
            )
            status = "FLAGGED" if result.flagged else "clean"
            categories = ", ".join(result.categories) if result.categories else "none"
            embed = discord.Embed(
                title=f"Moderation result: {status}",
                color=discord.Color.red() if result.flagged else discord.Color.green(),
            )
            embed.add_field(name="Categories", value=categories, inline=False)
            await interaction.followup.send(embed=embed, ephemeral=True)
        except Exception:  # noqa: BLE001
            logger.exception("moderate command failed")
            await interaction.followup.send("Something went wrong while checking that text.", ephemeral=True)

    @app_commands.command(name="purge", description="Bulk-delete recent messages in this channel.")
    @app_commands.describe(amount="Number of messages to delete (1-100).")
    @app_commands.checks.has_permissions(manage_messages=True)
    async def purge(self, interaction: discord.Interaction, amount: app_commands.Range[int, 1, 100]) -> None:
        if not isinstance(interaction.channel, discord.TextChannel):
            await interaction.response.send_message("This command only works in text channels.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True, thinking=True)
        deleted = await interaction.channel.purge(limit=amount)
        await interaction.followup.send(f"Deleted {len(deleted)} messages.", ephemeral=True)

    @moderate.error
    @purge.error
    async def on_permission_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError) -> None:
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message(
                "You need the **Manage Messages** permission to use this command.", ephemeral=True
            )
            return
        logger.exception("Unhandled moderation command error", exc_info=error)
        if interaction.response.is_done():
            await interaction.followup.send("Something went wrong.", ephemeral=True)
        else:
            await interaction.response.send_message("Something went wrong.", ephemeral=True)
