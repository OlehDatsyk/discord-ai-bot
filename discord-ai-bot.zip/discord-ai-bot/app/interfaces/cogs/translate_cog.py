"""``/translate`` slash command."""
from __future__ import annotations

import logging

import discord
from discord import app_commands
from discord.ext import commands

from app.container import ServiceContainer

logger = logging.getLogger(__name__)


class TranslateCog(commands.Cog):
    def __init__(self, container: ServiceContainer) -> None:
        self.container = container

    @app_commands.command(name="translate", description="Translate text into another language.")
    @app_commands.describe(text="The text to translate.", language="Target language, e.g. 'Spanish' or 'ja'.")
    async def translate(self, interaction: discord.Interaction, text: str, language: str) -> None:
        await interaction.response.defer(thinking=True)
        try:
            translated = await self.container.translate_service.translate(text, target_language=language)
            embed = discord.Embed(
                title=f"Translation ({language})",
                description=translated,
                color=discord.Color.green(),
            )
            await interaction.followup.send(embed=embed)
        except ValueError as exc:
            await interaction.followup.send(f"Could not translate: {exc}")
        except Exception:  # noqa: BLE001
            logger.exception("translate command failed")
            await interaction.followup.send("Something went wrong while translating. Please try again.")
