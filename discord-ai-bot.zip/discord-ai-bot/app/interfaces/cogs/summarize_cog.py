"""``/summarize`` slash command."""
from __future__ import annotations

import logging

import discord
from discord import app_commands
from discord.ext import commands

from app.container import ServiceContainer

logger = logging.getLogger(__name__)


class SummarizeCog(commands.Cog):
    def __init__(self, container: ServiceContainer) -> None:
        self.container = container

    @app_commands.command(name="summarize", description="Summarize a block of text.")
    @app_commands.describe(text="The text you want summarized.")
    async def summarize(self, interaction: discord.Interaction, text: str) -> None:
        await interaction.response.defer(thinking=True)
        try:
            settings = await self.container.settings_service.get_settings(str(interaction.user.id))
            summary = await self.container.summarize_service.summarize(text, language=settings.language)
            embed = discord.Embed(
                title="Summary",
                description=summary,
                color=discord.Color.blurple(),
            )
            await interaction.followup.send(embed=embed)
        except ValueError as exc:
            await interaction.followup.send(f"Could not summarize: {exc}")
        except Exception:  # noqa: BLE001
            logger.exception("summarize command failed")
            await interaction.followup.send("Something went wrong while summarizing. Please try again.")
