"""``/chat`` slash command: conversational AI with per-user memory."""
from __future__ import annotations

import logging

import discord
from discord import app_commands
from discord.ext import commands

from app.container import ServiceContainer

logger = logging.getLogger(__name__)


class ChatCog(commands.Cog):
    def __init__(self, container: ServiceContainer) -> None:
        self.container = container

    @app_commands.command(name="chat", description="Chat with the AI assistant.")
    @app_commands.describe(message="What do you want to say?")
    async def chat(self, interaction: discord.Interaction, message: str) -> None:
        await interaction.response.defer(thinking=True)
        try:
            reply = await self.container.chat_service.chat(
                guild_id=str(interaction.guild_id or "dm"),
                channel_id=str(interaction.channel_id),
                user_id=str(interaction.user.id),
                message=message,
            )
            await interaction.followup.send(reply)
        except Exception:  # noqa: BLE001
            logger.exception("chat command failed")
            await interaction.followup.send(
                "Something went wrong while talking to the AI. Please try again shortly."
            )
