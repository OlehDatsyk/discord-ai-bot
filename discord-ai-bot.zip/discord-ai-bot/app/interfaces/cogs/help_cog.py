"""``/help`` slash command."""
from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from app.container import ServiceContainer

_COMMANDS = [
    ("/chat <message>", "Chat with the AI assistant. Remembers recent context per channel."),
    ("/summarize <text>", "Summarize a block of text into key points."),
    ("/translate <text> <language>", "Translate text into another language."),
    ("/settings view|persona|language|model", "View or change your personal preferences."),
    ("/history view|clear", "View or clear your stored conversation history."),
    ("/moderate <text>", "Check text against OpenAI's moderation categories (admin/mod tools)."),
    ("/purge <amount>", "Bulk-delete recent messages in this channel (requires Manage Messages)."),
    ("/help", "Show this help message."),
]


class HelpCog(commands.Cog):
    def __init__(self, container: ServiceContainer) -> None:
        self.container = container

    @app_commands.command(name="help", description="List all available commands.")
    async def help(self, interaction: discord.Interaction) -> None:
        embed = discord.Embed(
            title="Discord AI Bot - Commands",
            description="Here is everything I can do:",
            color=discord.Color.blurple(),
        )
        for name, description in _COMMANDS:
            embed.add_field(name=name, value=description, inline=False)
        embed.set_footer(text="Powered by the OpenAI Responses API")
        await interaction.response.send_message(embed=embed, ephemeral=True)
