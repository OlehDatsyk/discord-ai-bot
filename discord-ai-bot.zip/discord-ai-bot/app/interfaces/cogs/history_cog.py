"""``/history`` slash command: view or clear stored conversation memory."""
from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from app.container import ServiceContainer


class HistoryCog(commands.Cog):
    def __init__(self, container: ServiceContainer) -> None:
        self.container = container

    @app_commands.command(name="history", description="View or clear your recent conversation history in this channel.")
    @app_commands.describe(action="What to do with your history.")
    @app_commands.choices(
        action=[
            app_commands.Choice(name="view", value="view"),
            app_commands.Choice(name="clear", value="clear"),
        ]
    )
    async def history(self, interaction: discord.Interaction, action: app_commands.Choice[str]) -> None:
        guild_id = str(interaction.guild_id or "dm")
        channel_id = str(interaction.channel_id)
        user_id = str(interaction.user.id)

        if action.value == "clear":
            deleted = await self.container.memory_service.clear(guild_id, channel_id, user_id)
            await interaction.response.send_message(f"Cleared {deleted} stored messages.", ephemeral=True)
            return

        history = await self.container.memory_service.get_history(guild_id, channel_id, user_id)
        if not history:
            await interaction.response.send_message("No conversation history yet in this channel.", ephemeral=True)
            return

        lines = []
        for message in history[-10:]:
            speaker = "You" if message.role.value == "user" else "Bot"
            snippet = message.content if len(message.content) <= 150 else message.content[:150] + "..."
            lines.append(f"**{speaker}:** {snippet}")

        embed = discord.Embed(
            title="Recent Conversation History",
            description="\n".join(lines),
            color=discord.Color.orange(),
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)
