"""``/settings`` slash command group: manage persona, language, and model."""
from __future__ import annotations

import logging

import discord
from discord import app_commands
from discord.ext import commands

from app.container import ServiceContainer
from app.domain.models import Persona

logger = logging.getLogger(__name__)


class SettingsCog(commands.Cog):
    def __init__(self, container: ServiceContainer) -> None:
        self.container = container

    settings_group = app_commands.Group(name="settings", description="View or change your bot preferences.")

    @settings_group.command(name="view", description="Show your current preferences.")
    async def view(self, interaction: discord.Interaction) -> None:
        settings = await self.container.settings_service.get_settings(str(interaction.user.id))
        embed = discord.Embed(title="Your Settings", color=discord.Color.blurple())
        embed.add_field(name="Persona", value=settings.persona.value, inline=True)
        embed.add_field(name="Language", value=settings.language, inline=True)
        embed.add_field(name="Model override", value=settings.model or "(server default)", inline=True)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @settings_group.command(name="persona", description="Set the assistant's personality.")
    @app_commands.choices(
        persona=[app_commands.Choice(name=p.value, value=p.value) for p in Persona]
    )
    async def persona(self, interaction: discord.Interaction, persona: app_commands.Choice[str]) -> None:
        updated = await self.container.settings_service.update_persona(
            str(interaction.user.id), Persona(persona.value)
        )
        await interaction.response.send_message(f"Persona set to **{updated.persona.value}**.", ephemeral=True)

    @settings_group.command(name="language", description="Set your preferred reply language (ISO code, e.g. en, es, fr).")
    async def language(self, interaction: discord.Interaction, language: str) -> None:
        updated = await self.container.settings_service.update_language(str(interaction.user.id), language)
        await interaction.response.send_message(f"Language set to **{updated.language}**.", ephemeral=True)

    @settings_group.command(name="model", description="Override the OpenAI model used for your requests.")
    async def model(self, interaction: discord.Interaction, model: str | None = None) -> None:
        updated = await self.container.settings_service.update_model(str(interaction.user.id), model)
        label = updated.model or "server default"
        await interaction.response.send_message(f"Model override set to **{label}**.", ephemeral=True)
