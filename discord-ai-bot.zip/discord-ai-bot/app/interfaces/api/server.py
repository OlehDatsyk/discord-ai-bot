"""FastAPI application factory."""
from __future__ import annotations

from fastapi import FastAPI

from app.container import ServiceContainer
from app.interfaces.api.routes import automation_router, health_router


def create_app(container: ServiceContainer) -> FastAPI:
    app = FastAPI(
        title="Discord AI Bot - Automation API",
        description=(
            "Health checks and automation webhook endpoints used by n8n, "
            "Zapier, and Make to trigger the bot's AI features."
        ),
        version="1.0.0",
    )
    app.state.container = container
    app.state.bot = None  # set by main.py once the Discord client is created

    app.include_router(health_router)
    app.include_router(automation_router)

    return app
