"""Shared-secret authentication for automation webhook endpoints."""
from __future__ import annotations

from fastapi import Header, HTTPException, status

from app.config import get_settings


async def verify_webhook_secret(x_webhook_secret: str = Header(default="")) -> None:
    """FastAPI dependency that guards automation endpoints.

    n8n, Zapier, and Make must all send the header::

        X-Webhook-Secret: <value of WEBHOOK_SECRET in .env>
    """
    settings = get_settings()
    if not x_webhook_secret or x_webhook_secret != settings.webhook_secret:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or missing webhook secret.")
