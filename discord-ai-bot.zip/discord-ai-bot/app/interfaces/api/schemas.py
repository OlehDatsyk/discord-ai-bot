"""Pydantic v2 request/response models for the automation HTTP API."""
from __future__ import annotations

from pydantic import BaseModel, Field


class HealthResponse(BaseModel):
    status: str = "ok"
    bot_ready: bool


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=4000)
    user_id: str = Field(description="Stable identifier for the caller, e.g. an email or external user id.")
    guild_id: str = Field(default="automation")
    channel_id: str = Field(default="automation")


class ChatResponse(BaseModel):
    reply: str


class SummarizeRequest(BaseModel):
    text: str = Field(min_length=1, max_length=20_000)
    language: str = Field(default="en")


class SummarizeResponse(BaseModel):
    summary: str


class TranslateRequest(BaseModel):
    text: str = Field(min_length=1, max_length=6_000)
    target_language: str = Field(min_length=2)


class TranslateResponse(BaseModel):
    translation: str


class ModerateRequest(BaseModel):
    text: str = Field(min_length=1, max_length=6_000)


class ModerateResponse(BaseModel):
    flagged: bool
    categories: list[str]
