"""
Automation-facing HTTP routes.

These endpoints let n8n, Zapier, and Make trigger the bot's AI features
from outside Discord (e.g. "summarize this support ticket and post it to
Slack"). All routes below ``/automation`` require the ``X-Webhook-Secret``
header (see :mod:`app.interfaces.api.security`).
"""
from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Request

from app.container import ServiceContainer
from app.interfaces.api.schemas import (
    ChatRequest,
    ChatResponse,
    HealthResponse,
    ModerateRequest,
    ModerateResponse,
    SummarizeRequest,
    SummarizeResponse,
    TranslateRequest,
    TranslateResponse,
)
from app.interfaces.api.security import verify_webhook_secret

logger = logging.getLogger(__name__)

health_router = APIRouter(tags=["health"])
automation_router = APIRouter(prefix="/automation", tags=["automation"], dependencies=[Depends(verify_webhook_secret)])


def get_container(request: Request) -> ServiceContainer:
    return request.app.state.container


@health_router.get("/health", response_model=HealthResponse)
async def health(request: Request) -> HealthResponse:
    bot = getattr(request.app.state, "bot", None)
    bot_ready = bool(bot and bot.is_ready())
    return HealthResponse(bot_ready=bot_ready)


@automation_router.post("/chat", response_model=ChatResponse)
async def automation_chat(payload: ChatRequest, request: Request) -> ChatResponse:
    container: ServiceContainer = request.app.state.container
    reply = await container.chat_service.chat(
        guild_id=payload.guild_id,
        channel_id=payload.channel_id,
        user_id=payload.user_id,
        message=payload.message,
    )
    return ChatResponse(reply=reply)


@automation_router.post("/summarize", response_model=SummarizeResponse)
async def automation_summarize(payload: SummarizeRequest, request: Request) -> SummarizeResponse:
    container: ServiceContainer = request.app.state.container
    try:
        summary = await container.summarize_service.summarize(payload.text, language=payload.language)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return SummarizeResponse(summary=summary)


@automation_router.post("/translate", response_model=TranslateResponse)
async def automation_translate(payload: TranslateRequest, request: Request) -> TranslateResponse:
    container: ServiceContainer = request.app.state.container
    try:
        translation = await container.translate_service.translate(
            payload.text, target_language=payload.target_language
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return TranslateResponse(translation=translation)


@automation_router.post("/moderate", response_model=ModerateResponse)
async def automation_moderate(payload: ModerateRequest, request: Request) -> ModerateResponse:
    container: ServiceContainer = request.app.state.container
    result = await container.moderation_service.check_message(payload.text)
    return ModerateResponse(flagged=result.flagged, categories=result.categories)
