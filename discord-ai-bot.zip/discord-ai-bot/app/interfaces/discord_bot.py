"""Discord bot factory: builds the client, loads cogs, and syncs slash commands."""
from __future__ import annotations

import logging

import discord
from discord.ext import commands

from app.container import ServiceContainer

logger = logging.getLogger(__name__)


class DiscordAIBot(commands.Bot):
    """Custom bot subclass carrying the shared service container."""

    def __init__(self, container: ServiceContainer) -> None:
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = False
        super().__init__(command_prefix="!", intents=intents, help_command=None)
        self.container = container

    async def setup_hook(self) -> None:
        from app.interfaces.cogs.chat_cog import ChatCog
        from app.interfaces.cogs.help_cog import HelpCog
        from app.interfaces.cogs.history_cog import HistoryCog
        from app.interfaces.cogs.moderation_cog import ModerationCog
        from app.interfaces.cogs.settings_cog import SettingsCog
        from app.interfaces.cogs.summarize_cog import SummarizeCog
        from app.interfaces.cogs.translate_cog import TranslateCog

        for cog_cls in (ChatCog, SummarizeCog, TranslateCog, SettingsCog, HistoryCog, HelpCog, ModerationCog):
            await self.add_cog(cog_cls(self.container))
            logger.info("Loaded cog: %s", cog_cls.__name__)

        guild_id = self.container.settings.discord_guild_id
        if guild_id:
            guild = discord.Object(id=guild_id)
            self.tree.copy_global_to(guild=guild)
            synced = await self.tree.sync(guild=guild)
            logger.info("Synced %d slash commands to guild %s (instant).", len(synced), guild_id)
        else:
            synced = await self.tree.sync()
            logger.info("Synced %d slash commands globally (may take up to 1 hour to appear).", len(synced))

    async def on_ready(self) -> None:
        logger.info("Logged in as %s (id=%s)", self.user, self.user.id if self.user else "unknown")
        await self.change_presence(activity=discord.Game(name="/help for commands"))


def build_bot(container: ServiceContainer) -> DiscordAIBot:
    return DiscordAIBot(container)
