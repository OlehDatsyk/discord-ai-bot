"""Repository for persisting per-user settings/preferences."""
from __future__ import annotations

from pathlib import Path

from app.domain.models import Persona, UserSettings
from app.infrastructure.database import get_connection


class SettingsRepository:
    """CRUD operations for the ``user_settings`` table."""

    def __init__(self, database_path: Path) -> None:
        self._database_path = database_path

    async def get(self, user_id: str) -> UserSettings | None:
        async with get_connection(self._database_path) as db:
            cursor = await db.execute(
                "SELECT user_id, persona, language, model FROM user_settings WHERE user_id = ?",
                (user_id,),
            )
            row = await cursor.fetchone()

        if row is None:
            return None

        return UserSettings(
            user_id=row["user_id"],
            persona=Persona(row["persona"]),
            language=row["language"],
            model=row["model"],
        )

    async def get_or_create(self, user_id: str) -> UserSettings:
        existing = await self.get(user_id)
        if existing is not None:
            return existing

        defaults = UserSettings(user_id=user_id)
        async with get_connection(self._database_path) as db:
            await db.execute(
                "INSERT OR IGNORE INTO user_settings (user_id, persona, language, model) VALUES (?, ?, ?, ?)",
                (defaults.user_id, defaults.persona.value, defaults.language, defaults.model),
            )
            await db.commit()
        return defaults

    async def upsert(self, settings: UserSettings) -> None:
        async with get_connection(self._database_path) as db:
            await db.execute(
                """
                INSERT INTO user_settings (user_id, persona, language, model)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(user_id) DO UPDATE SET
                    persona = excluded.persona,
                    language = excluded.language,
                    model = excluded.model
                """,
                (settings.user_id, settings.persona.value, settings.language, settings.model),
            )
            await db.commit()
