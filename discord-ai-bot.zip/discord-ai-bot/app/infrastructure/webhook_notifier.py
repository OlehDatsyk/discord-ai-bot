"""
Outbound webhook notifier.

Allows the bot to *push* events (e.g. a flagged message, a new summary) to
external automation platforms such as n8n, Zapier, or Make. This is the
"bot -> automation" direction; the "automation -> bot" direction is handled
by ``app/interfaces/api/routes.py``.

Uses aiohttp, which is already a dependency of discord.py, so no extra
package is required.
"""
from __future__ import annotations

import logging
from typing import Any

import aiohttp

logger = logging.getLogger(__name__)


class WebhookNotifier:
    """Fire-and-forget POST requests to configured automation webhook URLs."""

    def __init__(
        self,
        n8n_url: str | None = None,
        zapier_url: str | None = None,
        make_url: str | None = None,
    ) -> None:
        self._urls: dict[str, str] = {
            name: url
            for name, url in (("n8n", n8n_url), ("zapier", zapier_url), ("make", make_url))
            if url
        }

    @property
    def enabled(self) -> bool:
        return bool(self._urls)

    async def notify_all(self, event: str, payload: dict[str, Any]) -> None:
        """Send ``payload`` (tagged with ``event``) to every configured platform."""
        if not self._urls:
            return

        body = {"event": event, **payload}
        async with aiohttp.ClientSession() as session:
            for platform, url in self._urls.items():
                try:
                    async with session.post(url, json=body, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                        if resp.status >= 400:
                            logger.warning("Webhook to %s returned HTTP %s", platform, resp.status)
                except Exception:  # noqa: BLE001 - never let a webhook failure crash the bot
                    logger.exception("Failed to notify %s webhook", platform)
