"""
SQLite database access layer.

Uses aiosqlite so the Discord bot (which is fully async) never blocks the
event loop on disk I/O. Schema creation is idempotent and safe to run on
every startup.
"""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from pathlib import Path
from typing import AsyncIterator

import aiosqlite

logger = logging.getLogger(__name__)

_SCHEMA = """
CREATE TABLE IF NOT EXISTS conversation_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT NOT NULL,
    channel_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_conversation_scope
    ON conversation_messages (guild_id, channel_id, user_id, created_at);

CREATE TABLE IF NOT EXISTS user_settings (
    user_id TEXT PRIMARY KEY,
    persona TEXT NOT NULL DEFAULT 'default',
    language TEXT NOT NULL DEFAULT 'en',
    model TEXT
);
"""


async def init_db(database_path: Path) -> None:
    """Create the SQLite file (and parent directory) and apply the schema."""
    database_path.parent.mkdir(parents=True, exist_ok=True)
    async with aiosqlite.connect(database_path) as db:
        await db.executescript(_SCHEMA)
        await db.commit()
    logger.info("Database ready at %s", database_path)


@asynccontextmanager
async def get_connection(database_path: Path) -> AsyncIterator[aiosqlite.Connection]:
    """Yield a short-lived SQLite connection with row access by column name."""
    db = await aiosqlite.connect(database_path)
    db.row_factory = aiosqlite.Row
    try:
        yield db
    finally:
        await db.close()
