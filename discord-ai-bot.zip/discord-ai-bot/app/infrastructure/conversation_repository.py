"""Repository for persisting and retrieving conversation history."""
from __future__ import annotations

import logging
from pathlib import Path

from app.domain.models import ConversationMessage, MessageRole
from app.infrastructure.database import get_connection

logger = logging.getLogger(__name__)


class ConversationRepository:
    """CRUD operations for the ``conversation_messages`` table."""

    def __init__(self, database_path: Path) -> None:
        self._database_path = database_path

    async def add_message(self, message: ConversationMessage) -> None:
        async with get_connection(self._database_path) as db:
            await db.execute(
                """
                INSERT INTO conversation_messages
                    (guild_id, channel_id, user_id, role, content)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    message.guild_id,
                    message.channel_id,
                    message.user_id,
                    message.role.value,
                    message.content,
                ),
            )
            await db.commit()

    async def get_recent(
        self, guild_id: str, channel_id: str, user_id: str, limit: int
    ) -> list[ConversationMessage]:
        async with get_connection(self._database_path) as db:
            cursor = await db.execute(
                """
                SELECT id, guild_id, channel_id, user_id, role, content, created_at
                FROM conversation_messages
                WHERE guild_id = ? AND channel_id = ? AND user_id = ?
                ORDER BY id DESC
                LIMIT ?
                """,
                (guild_id, channel_id, user_id, limit),
            )
            rows = await cursor.fetchall()

        messages = [
            ConversationMessage(
                id=row["id"],
                guild_id=row["guild_id"],
                channel_id=row["channel_id"],
                user_id=row["user_id"],
                role=MessageRole(row["role"]),
                content=row["content"],
                created_at=row["created_at"],
            )
            for row in rows
        ]
        # Rows were fetched newest-first; return oldest-first for prompt building.
        return list(reversed(messages))

    async def clear(self, guild_id: str, channel_id: str, user_id: str) -> int:
        async with get_connection(self._database_path) as db:
            cursor = await db.execute(
                """
                DELETE FROM conversation_messages
                WHERE guild_id = ? AND channel_id = ? AND user_id = ?
                """,
                (guild_id, channel_id, user_id),
            )
            await db.commit()
            return cursor.rowcount

    async def trim(self, guild_id: str, channel_id: str, user_id: str, keep_last: int) -> None:
        """Delete old rows beyond ``keep_last`` to prevent unbounded growth."""
        async with get_connection(self._database_path) as db:
            await db.execute(
                """
                DELETE FROM conversation_messages
                WHERE guild_id = ? AND channel_id = ? AND user_id = ?
                AND id NOT IN (
                    SELECT id FROM conversation_messages
                    WHERE guild_id = ? AND channel_id = ? AND user_id = ?
                    ORDER BY id DESC
                    LIMIT ?
                )
                """,
                (guild_id, channel_id, user_id, guild_id, channel_id, user_id, keep_last),
            )
            await db.commit()
