"""
Thin async wrapper around the OpenAI Python SDK.

This is the ONLY module allowed to import ``openai`` directly. Every other
layer depends on this abstraction, which keeps the rest of the codebase
testable and decoupled from the SDK's exact shape.
"""
from __future__ import annotations

import logging

from openai import AsyncOpenAI

from app.domain.models import ModerationResult

logger = logging.getLogger(__name__)


class OpenAIClient:
    """Wraps the OpenAI Responses API and Moderation API."""

    def __init__(self, api_key: str, default_model: str, moderation_model: str) -> None:
        self._client = AsyncOpenAI(api_key=api_key)
        self._default_model = default_model
        self._moderation_model = moderation_model

    async def generate_reply(
        self,
        *,
        instructions: str,
        input_items: list[dict[str, str]],
        model: str | None = None,
        max_output_tokens: int = 800,
    ) -> str:
        """Call the Responses API and return plain text output.

        ``input_items`` is a list of ``{"role": "user"|"assistant", "content": "..."}``
        dicts representing the conversation turns (system instructions are
        passed separately via ``instructions``).
        """
        response = await self._client.responses.create(
            model=model or self._default_model,
            instructions=instructions,
            input=input_items,
            max_output_tokens=max_output_tokens,
        )
        text = getattr(response, "output_text", None)
        if not text:
            logger.warning("OpenAI response had no output_text; returning fallback message.")
            return "I couldn't generate a response for that. Please try again."
        return text.strip()

    async def summarize(self, text: str, *, language: str = "en", model: str | None = None) -> str:
        instructions = (
            "You are a precise summarization assistant. Summarize the user's text "
            f"in {language}. Preserve key facts, numbers, and names. Use concise "
            "bullet points when the source text covers multiple topics, otherwise "
            "write 2-4 sentences. Never add information that is not in the source."
        )
        return await self.generate_reply(
            instructions=instructions,
            input_items=[{"role": "user", "content": text}],
            model=model,
        )

    async def translate(self, text: str, *, target_language: str, model: str | None = None) -> str:
        instructions = (
            f"You are a professional translator. Translate the user's message into "
            f"{target_language}. Preserve tone, formatting, and meaning. Reply with "
            "ONLY the translated text, no explanations or quotation marks."
        )
        return await self.generate_reply(
            instructions=instructions,
            input_items=[{"role": "user", "content": text}],
            model=model,
        )

    async def moderate(self, text: str) -> ModerationResult:
        response = await self._client.moderations.create(
            model=self._moderation_model,
            input=text,
        )
        result = response.results[0]
        flagged_categories = [
            category
            for category, is_flagged in result.categories.model_dump().items()
            if is_flagged
        ]
        return ModerationResult(
            flagged=result.flagged,
            categories=flagged_categories,
            original_text=text,
        )
