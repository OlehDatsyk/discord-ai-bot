"""
Application entrypoint.

Starts the Discord bot and the FastAPI automation API concurrently inside
a single asyncio event loop. Run with::

    python -m app.main
"""
from __future__ import annotations

import asyncio
import logging
import signal

import uvicorn

from app.config import get_settings
from app.container import build_container
from app.infrastructure.database import init_db
from app.infrastructure.logging_config import configure_logging
from app.interfaces.api.server import create_app
from app.interfaces.discord_bot import build_bot

logger = logging.getLogger(__name__)


async def run() -> None:
    settings = get_settings()
    configure_logging(settings.log_level)

    logger.info("Starting Discord AI Bot...")
    await init_db(settings.database_path)

    container = build_container(settings)
    bot = build_bot(container)

    fastapi_app = create_app(container)
    fastapi_app.state.bot = bot

    uvicorn_config = uvicorn.Config(
        fastapi_app,
        host=settings.api_host,
        port=settings.api_port,
        log_level=settings.log_level.lower(),
        access_log=settings.log_level.upper() == "DEBUG",
    )
    server = uvicorn.Server(uvicorn_config)

    stop_event = asyncio.Event()

    def _handle_stop_signal(*_args: object) -> None:
        logger.info("Shutdown signal received.")
        stop_event.set()

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _handle_stop_signal)
        except NotImplementedError:
            # add_signal_handler is not available on Windows event loops.
            pass

    async def _run_bot() -> None:
        async with bot:
            await bot.start(settings.discord_bot_token)

    bot_task = asyncio.create_task(_run_bot(), name="discord-bot")
    api_task = asyncio.create_task(server.serve(), name="fastapi-server")
    stop_task = asyncio.create_task(stop_event.wait(), name="stop-signal")

    done, pending = await asyncio.wait(
        {bot_task, api_task, stop_task},
        return_when=asyncio.FIRST_COMPLETED,
    )

    logger.info("Shutting down...")
    server.should_exit = True
    if not bot.is_closed():
        await bot.close()

    for task in pending:
        task.cancel()
    await asyncio.gather(*pending, return_exceptions=True)

    for task in done:
        if task is not stop_task and task.exception():
            logger.error("Task %s exited with an error", task.get_name(), exc_info=task.exception())


def main() -> None:
    try:
        asyncio.run(run())
    except KeyboardInterrupt:
        logging.getLogger(__name__).info("Interrupted by user. Goodbye!")


if __name__ == "__main__":
    main()
