"""
Composition root.

Builds every concrete implementation once and wires them together. Both the
Discord bot and the FastAPI app receive the same :class:`ServiceContainer`
instance, so they always share one database, one OpenAI client, and one
in-memory cache lifecycle.
"""
from __future__ import annotations

from dataclasses import dataclass

from app.application.chat_service import ChatService
from app.application.memory_service import MemoryService
from app.application.moderation_service import ModerationService
from app.application.settings_service import SettingsService
from app.application.summarize_service import SummarizeService
from app.application.translate_service import TranslateService
from app.config import Settings
from app.infrastructure.conversation_repository import ConversationRepository
from app.infrastructure.openai_client import OpenAIClient
from app.infrastructure.settings_repository import SettingsRepository
from app.infrastructure.webhook_notifier import WebhookNotifier


@dataclass(slots=True)
class ServiceContainer:
    settings: Settings
    openai_client: OpenAIClient
    webhook_notifier: WebhookNotifier
    memory_service: MemoryService
    settings_service: SettingsService
    chat_service: ChatService
    summarize_service: SummarizeService
    translate_service: TranslateService
    moderation_service: ModerationService


def build_container(settings: Settings) -> ServiceContainer:
    """Instantiate and wire every service. Call once at process startup."""
    openai_client = OpenAIClient(
        api_key=settings.openai_api_key,
        default_model=settings.openai_model,
        moderation_model=settings.openai_moderation_model,
    )
    webhook_notifier = WebhookNotifier(
        n8n_url=settings.n8n_webhook_url,
        zapier_url=settings.zapier_webhook_url,
        make_url=settings.make_webhook_url,
    )

    conversation_repository = ConversationRepository(settings.database_path)
    settings_repository = SettingsRepository(settings.database_path)

    memory_service = MemoryService(conversation_repository, settings.conversation_history_limit)
    settings_service = SettingsService(settings_repository)

    chat_service = ChatService(
        openai_client=openai_client,
        memory_service=memory_service,
        settings_service=settings_service,
        max_output_tokens=settings.openai_max_output_tokens,
    )
    summarize_service = SummarizeService(openai_client)
    translate_service = TranslateService(openai_client)
    moderation_service = ModerationService(openai_client, webhook_notifier)

    return ServiceContainer(
        settings=settings,
        openai_client=openai_client,
        webhook_notifier=webhook_notifier,
        memory_service=memory_service,
        settings_service=settings_service,
        chat_service=chat_service,
        summarize_service=summarize_service,
        translate_service=translate_service,
        moderation_service=moderation_service,
    )
