"""
Application configuration.

All runtime configuration is loaded from environment variables (or a local
``.env`` file). This is the ONLY module in the codebase that is allowed to
read from the environment directly - every other module receives an already
validated :class:`Settings` instance via dependency injection.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Strongly typed application settings, validated with Pydantic v2."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ------------------------------------------------------------------ #
    # Discord
    # ------------------------------------------------------------------ #
    discord_bot_token: str = Field(
        description="Bot token from the Discord Developer Portal.",
    )
    discord_guild_id: int | None = Field(
        default=None,
        description="Optional guild (server) ID used for instant slash-command sync during development.",
    )

    # ------------------------------------------------------------------ #
    # OpenAI
    # ------------------------------------------------------------------ #
    openai_api_key: str = Field(description="Secret API key from platform.openai.com.")
    openai_model: str = Field(default="gpt-4.1-mini", description="Model used for chat/summarize/translate.")
    openai_moderation_model: str = Field(default="omni-moderation-latest")
    openai_max_output_tokens: int = Field(default=800, ge=16, le=4096)

    # ------------------------------------------------------------------ #
    # Database
    # ------------------------------------------------------------------ #
    database_path: Path = Field(default=Path("data/bot.db"))

    # ------------------------------------------------------------------ #
    # Conversation memory
    # ------------------------------------------------------------------ #
    conversation_history_limit: int = Field(
        default=10,
        ge=1,
        le=50,
        description="Number of past messages (per user/channel) kept as context.",
    )

    # ------------------------------------------------------------------ #
    # HTTP API (health check + automation webhooks for n8n/Zapier/Make)
    # ------------------------------------------------------------------ #
    api_host: str = Field(default="0.0.0.0")
    api_port: int = Field(default=8000)
    webhook_secret: str = Field(
        default="change-me",
        description="Shared secret required in the X-Webhook-Secret header for automation endpoints.",
    )

    # Optional outbound webhooks that the bot can notify (e.g. on flagged content)
    n8n_webhook_url: str | None = Field(default=None)
    zapier_webhook_url: str | None = Field(default=None)
    make_webhook_url: str | None = Field(default=None)

    # ------------------------------------------------------------------ #
    # Logging
    # ------------------------------------------------------------------ #
    log_level: str = Field(default="INFO")

    @field_validator("database_path", mode="before")
    @classmethod
    def _coerce_path(cls, value: object) -> Path:
        return Path(value) if not isinstance(value, Path) else value

    @field_validator("log_level")
    @classmethod
    def _validate_log_level(cls, value: str) -> str:
        valid = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        upper = value.upper()
        if upper not in valid:
            raise ValueError(f"log_level must be one of {valid}, got {value!r}")
        return upper


@lru_cache
def get_settings() -> Settings:
    """Return a cached, validated Settings instance."""
    return Settings()
