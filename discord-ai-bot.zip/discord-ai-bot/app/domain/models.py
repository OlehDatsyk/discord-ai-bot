"""
Domain layer.

Pure data models with zero framework dependencies (no discord.py, no
FastAPI, no OpenAI SDK). This layer defines *what* the business concepts
are, independent of *how* they are stored or delivered.
"""
from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum

from pydantic import BaseModel, Field


class MessageRole(str, Enum):
    """Role of a single message inside a conversation."""

    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"


class Persona(str, Enum):
    """Available system-prompt personas a user may select via /settings."""

    DEFAULT = "default"
    FRIENDLY = "friendly"
    PROFESSIONAL = "professional"
    CODER = "coder"
    CONCISE = "concise"


class ConversationMessage(BaseModel):
    """A single stored turn of a conversation."""

    id: int | None = None
    guild_id: str
    channel_id: str
    user_id: str
    role: MessageRole
    content: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class UserSettings(BaseModel):
    """Per-user preferences persisted in SQLite."""

    user_id: str
    persona: Persona = Persona.DEFAULT
    language: str = Field(default="en", description="ISO-639-1 language code used for replies/translations.")
    model: str | None = Field(default=None, description="Optional per-user OpenAI model override.")


class ModerationResult(BaseModel):
    """Outcome of running a message through the OpenAI moderation endpoint."""

    flagged: bool
    categories: list[str] = Field(default_factory=list)
    original_text: str
