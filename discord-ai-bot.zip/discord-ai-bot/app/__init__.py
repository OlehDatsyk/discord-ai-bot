"""Discord AI Bot - Clean Architecture application package."""

__version__ = "1.0.0"
