"""Moderation use case: flags harmful content using the OpenAI moderation endpoint."""
from __future__ import annotations

import logging

from app.domain.models import ModerationResult
from app.infrastructure.openai_client import OpenAIClient
from app.infrastructure.webhook_notifier import WebhookNotifier

logger = logging.getLogger(__name__)


class ModerationService:
    def __init__(self, openai_client: OpenAIClient, webhook_notifier: WebhookNotifier | None = None) -> None:
        self._openai_client = openai_client
        self._webhook_notifier = webhook_notifier

    async def check_message(
        self,
        text: str,
        *,
        guild_id: str | None = None,
        channel_id: str | None = None,
        user_id: str | None = None,
    ) -> ModerationResult:
        result = await self._openai_client.moderate(text)

        if result.flagged:
            logger.warning("Flagged message from user=%s categories=%s", user_id, result.categories)
            if self._webhook_notifier is not None and self._webhook_notifier.enabled:
                await self._webhook_notifier.notify_all(
                    "message_flagged",
                    {
                        "guild_id": guild_id,
                        "channel_id": channel_id,
                        "user_id": user_id,
                        "categories": result.categories,
                        "text": result.original_text,
                    },
                )
        return result
