"""User preferences (persona, language, model override)."""
from __future__ import annotations

from app.domain.models import Persona, UserSettings
from app.infrastructure.settings_repository import SettingsRepository


class SettingsService:
    """Coordinates reading/updating per-user settings."""

    def __init__(self, repository: SettingsRepository) -> None:
        self._repository = repository

    async def get_settings(self, user_id: str) -> UserSettings:
        return await self._repository.get_or_create(user_id)

    async def update_persona(self, user_id: str, persona: Persona) -> UserSettings:
        settings = await self._repository.get_or_create(user_id)
        settings.persona = persona
        await self._repository.upsert(settings)
        return settings

    async def update_language(self, user_id: str, language: str) -> UserSettings:
        settings = await self._repository.get_or_create(user_id)
        settings.language = language.lower().strip()
        await self._repository.upsert(settings)
        return settings

    async def update_model(self, user_id: str, model: str | None) -> UserSettings:
        settings = await self._repository.get_or_create(user_id)
        settings.model = model
        await self._repository.upsert(settings)
        return settings
