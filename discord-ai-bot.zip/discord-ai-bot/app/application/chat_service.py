"""Core AI chat orchestration used by the /chat command and the chat webhook."""
from __future__ import annotations

import logging

from app.application.memory_service import MemoryService
from app.application.prompt_templates import get_system_prompt
from app.application.settings_service import SettingsService
from app.domain.models import MessageRole
from app.infrastructure.openai_client import OpenAIClient

logger = logging.getLogger(__name__)

_MAX_DISCORD_MESSAGE_LENGTH = 1900  # leaves headroom under Discord's 2000 char limit


class ChatService:
    """Builds context, calls OpenAI, and persists the conversation turn."""

    def __init__(
        self,
        openai_client: OpenAIClient,
        memory_service: MemoryService,
        settings_service: SettingsService,
        max_output_tokens: int,
    ) -> None:
        self._openai_client = openai_client
        self._memory_service = memory_service
        self._settings_service = settings_service
        self._max_output_tokens = max_output_tokens

    async def chat(self, *, guild_id: str, channel_id: str, user_id: str, message: str) -> str:
        settings = await self._settings_service.get_settings(user_id)
        system_prompt = get_system_prompt(settings.persona, settings.language)

        history = await self._memory_service.get_history(guild_id, channel_id, user_id)
        input_items = self._memory_service.to_openai_input(history)
        input_items.append({"role": "user", "content": message})

        reply = await self._openai_client.generate_reply(
            instructions=system_prompt,
            input_items=input_items,
            model=settings.model,
            max_output_tokens=self._max_output_tokens,
        )

        if len(reply) > _MAX_DISCORD_MESSAGE_LENGTH:
            reply = reply[: _MAX_DISCORD_MESSAGE_LENGTH - 3] + "..."

        await self._memory_service.remember(guild_id, channel_id, user_id, MessageRole.USER, message)
        await self._memory_service.remember(guild_id, channel_id, user_id, MessageRole.ASSISTANT, reply)

        return reply
