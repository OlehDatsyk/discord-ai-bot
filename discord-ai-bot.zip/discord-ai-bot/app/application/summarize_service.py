"""Summarization use case."""
from __future__ import annotations

from app.infrastructure.openai_client import OpenAIClient

_MAX_INPUT_CHARS = 12_000  # keeps requests fast and within reasonable token budgets


class SummarizeService:
    def __init__(self, openai_client: OpenAIClient) -> None:
        self._openai_client = openai_client

    async def summarize(self, text: str, *, language: str = "en", model: str | None = None) -> str:
        cleaned = text.strip()
        if not cleaned:
            raise ValueError("Cannot summarize empty text.")
        if len(cleaned) > _MAX_INPUT_CHARS:
            cleaned = cleaned[:_MAX_INPUT_CHARS]
        return await self._openai_client.summarize(cleaned, language=language, model=model)
