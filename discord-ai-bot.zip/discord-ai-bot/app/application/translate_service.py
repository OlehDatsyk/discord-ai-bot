"""Translation use case."""
from __future__ import annotations

from app.infrastructure.openai_client import OpenAIClient

_MAX_INPUT_CHARS = 6_000


class TranslateService:
    def __init__(self, openai_client: OpenAIClient) -> None:
        self._openai_client = openai_client

    async def translate(self, text: str, *, target_language: str, model: str | None = None) -> str:
        cleaned = text.strip()
        if not cleaned:
            raise ValueError("Cannot translate empty text.")
        if not target_language.strip():
            raise ValueError("A target language is required.")
        if len(cleaned) > _MAX_INPUT_CHARS:
            cleaned = cleaned[:_MAX_INPUT_CHARS]
        return await self._openai_client.translate(cleaned, target_language=target_language, model=model)
