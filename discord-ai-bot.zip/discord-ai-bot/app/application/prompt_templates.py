"""
Prompt templates.

Maps each :class:`~app.domain.models.Persona` to a system-instructions
string used when talking to the OpenAI Responses API. Keeping these in one
place makes tone/behaviour easy to tune without touching service logic.
"""
from __future__ import annotations

from app.domain.models import Persona

_BASE = (
    "You are a helpful AI assistant embedded in a Discord server. "
    "Keep replies under 1800 characters so they fit in a single Discord "
    "message. Use Markdown formatting where useful (bold, code blocks, "
    "lists) but avoid excessive headers."
)

_PERSONA_INSTRUCTIONS: dict[Persona, str] = {
    Persona.DEFAULT: _BASE,
    Persona.FRIENDLY: (
        _BASE + " Be warm, upbeat, and encouraging. Use a casual, friendly "
        "tone and the occasional emoji, without overdoing it."
    ),
    Persona.PROFESSIONAL: (
        _BASE + " Be formal, precise, and businesslike. Avoid slang, "
        "emoji, and filler words. Prioritize clarity and correctness."
    ),
    Persona.CODER: (
        _BASE + " You are a senior software engineer. Prefer code blocks "
        "with the correct language tag, explain trade-offs briefly, and "
        "call out bugs or edge cases proactively."
    ),
    Persona.CONCISE: (
        _BASE + " Be extremely concise. Prefer one or two sentences. "
        "Only elaborate if explicitly asked to."
    ),
}


def get_system_prompt(persona: Persona, language: str = "en") -> str:
    """Return the full system-instructions string for a persona + language."""
    instructions = _PERSONA_INSTRUCTIONS.get(persona, _BASE)
    if language and language.lower() != "en":
        instructions += f" Always reply in the language with ISO code '{language}'."
    return instructions
