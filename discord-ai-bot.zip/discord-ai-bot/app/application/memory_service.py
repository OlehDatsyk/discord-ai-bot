"""Conversation memory: reading/writing chat history used as OpenAI context."""
from __future__ import annotations

from app.domain.models import ConversationMessage, MessageRole
from app.infrastructure.conversation_repository import ConversationRepository


class MemoryService:
    """Coordinates conversation history storage and retrieval."""

    def __init__(self, repository: ConversationRepository, history_limit: int) -> None:
        self._repository = repository
        self._history_limit = history_limit

    async def get_history(self, guild_id: str, channel_id: str, user_id: str) -> list[ConversationMessage]:
        return await self._repository.get_recent(guild_id, channel_id, user_id, self._history_limit)

    async def remember(
        self, guild_id: str, channel_id: str, user_id: str, role: MessageRole, content: str
    ) -> None:
        message = ConversationMessage(
            guild_id=guild_id,
            channel_id=channel_id,
            user_id=user_id,
            role=role,
            content=content,
        )
        await self._repository.add_message(message)
        # Keep the table bounded so history never grows without limit.
        await self._repository.trim(guild_id, channel_id, user_id, keep_last=self._history_limit * 4)

    async def clear(self, guild_id: str, channel_id: str, user_id: str) -> int:
        return await self._repository.clear(guild_id, channel_id, user_id)

    @staticmethod
    def to_openai_input(history: list[ConversationMessage]) -> list[dict[str, str]]:
        """Convert stored messages into Responses API ``input`` items."""
        return [
            {"role": "user" if m.role == MessageRole.USER else "assistant", "content": m.content}
            for m in history
            if m.role in (MessageRole.USER, MessageRole.ASSISTANT)
        ]
