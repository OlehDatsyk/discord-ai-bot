"""Unit tests for Settings validation."""
from __future__ import annotations

import pytest
from pydantic import ValidationError

from app.config import Settings


def _base_env(**overrides: str) -> dict[str, str]:
    env = {
        "DISCORD_BOT_TOKEN": "fake-token",
        "OPENAI_API_KEY": "fake-key",
    }
    env.update(overrides)
    return env


def test_settings_load_with_required_fields(monkeypatch: pytest.MonkeyPatch):
    for key, value in _base_env().items():
        monkeypatch.setenv(key, value)
    settings = Settings(_env_file=None)
    assert settings.discord_bot_token == "fake-token"
    assert settings.openai_api_key == "fake-key"
    assert settings.openai_model == "gpt-4.1-mini"


def test_missing_required_field_raises(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.delenv("DISCORD_BOT_TOKEN", raising=False)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    with pytest.raises(ValidationError):
        Settings(_env_file=None)


def test_invalid_log_level_raises(monkeypatch: pytest.MonkeyPatch):
    for key, value in _base_env(LOG_LEVEL="NOT_A_LEVEL").items():
        monkeypatch.setenv(key, value)
    with pytest.raises(ValidationError):
        Settings(_env_file=None)
