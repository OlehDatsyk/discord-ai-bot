"""Unit tests for prompt template generation."""
from __future__ import annotations

from app.application.prompt_templates import get_system_prompt
from app.domain.models import Persona


def test_default_persona_includes_base_instructions():
    prompt = get_system_prompt(Persona.DEFAULT, "en")
    assert "Discord" in prompt
    assert "language with ISO code" not in prompt


def test_non_english_language_appends_instruction():
    prompt = get_system_prompt(Persona.FRIENDLY, "es")
    assert "'es'" in prompt


def test_each_persona_produces_distinct_prompt():
    prompts = {p: get_system_prompt(p, "en") for p in Persona}
    assert len(set(prompts.values())) == len(Persona)
