"""Unit tests for MemoryService using a real temporary SQLite database."""
from __future__ import annotations

from pathlib import Path

import pytest

from app.application.memory_service import MemoryService
from app.domain.models import MessageRole
from app.infrastructure.conversation_repository import ConversationRepository
from app.infrastructure.database import init_db


@pytest.fixture
async def memory_service(tmp_path: Path) -> MemoryService:
    db_path = tmp_path / "test.db"
    await init_db(db_path)
    repository = ConversationRepository(db_path)
    return MemoryService(repository, history_limit=5)


@pytest.mark.asyncio
async def test_remember_and_retrieve_history(memory_service: MemoryService):
    await memory_service.remember("g1", "c1", "u1", MessageRole.USER, "hello")
    await memory_service.remember("g1", "c1", "u1", MessageRole.ASSISTANT, "hi there")

    history = await memory_service.get_history("g1", "c1", "u1")

    assert len(history) == 2
    assert history[0].content == "hello"
    assert history[1].content == "hi there"


@pytest.mark.asyncio
async def test_clear_removes_all_messages(memory_service: MemoryService):
    await memory_service.remember("g1", "c1", "u1", MessageRole.USER, "hello")
    deleted = await memory_service.clear("g1", "c1", "u1")
    history = await memory_service.get_history("g1", "c1", "u1")

    assert deleted == 1
    assert history == []


@pytest.mark.asyncio
async def test_history_is_scoped_per_user(memory_service: MemoryService):
    await memory_service.remember("g1", "c1", "u1", MessageRole.USER, "from u1")
    await memory_service.remember("g1", "c1", "u2", MessageRole.USER, "from u2")

    history_u1 = await memory_service.get_history("g1", "c1", "u1")

    assert len(history_u1) == 1
    assert history_u1[0].content == "from u1"


def test_to_openai_input_maps_roles_correctly():
    from app.domain.models import ConversationMessage

    messages = [
        ConversationMessage(guild_id="g", channel_id="c", user_id="u", role=MessageRole.USER, content="hi"),
        ConversationMessage(guild_id="g", channel_id="c", user_id="u", role=MessageRole.ASSISTANT, content="hello"),
    ]
    input_items = MemoryService.to_openai_input(messages)
    assert input_items == [
        {"role": "user", "content": "hi"},
        {"role": "assistant", "content": "hello"},
    ]
