# n8n Workflow: Support Ticket Summarizer

This workflow demonstrates the **"automation → bot"** direction: an external
event (a new support ticket) triggers a webhook, which calls your running
Discord AI Bot to summarize the ticket, then posts the result into a Discord
channel.

## Flow

```
Webhook (new ticket) --> HTTP Request (/automation/summarize) --> HTTP Request (Discord webhook) --> Respond to Webhook
```

## Setup

| Step | Action |
|------|--------|
| 1 | Open n8n and choose **Import from File**. |
| 2 | Select `discord-ai-bot-workflow.json`. |
| 3 | Open the **Summarize via Discord AI Bot** node and confirm the URL points at your running bot (`http://localhost:8000/automation/summarize` for local testing, or your deployed URL). |
| 4 | In n8n, add an environment variable `DISCORD_BOT_WEBHOOK_SECRET` matching the `WEBHOOK_SECRET` value in your bot's `.env` file. |
| 5 | Add an environment variable `DISCORD_NOTIFY_WEBHOOK_URL` set to a Discord channel webhook URL (Channel Settings → Integrations → Webhooks → New Webhook). |
| 6 | Activate the workflow, then send a test `POST` request to the generated webhook URL with body `{"ticket_text": "..."}`. |

## Example test request

```bash
curl -X POST https://your-n8n-instance/webhook/support-ticket \
  -H "Content-Type: application/json" \
  -d '{"ticket_text": "Customer cannot log in after password reset, receives 500 error on submit."}'
```

## Notes

- If your bot is not publicly reachable, expose it locally with a tunnel such
  as `ngrok http 8000` and use the generated HTTPS URL in the workflow.
- You can duplicate this workflow and swap the `/automation/summarize` node
  for `/automation/translate`, `/automation/chat`, or `/automation/moderate`
  to build translation, chat, or moderation automations.
