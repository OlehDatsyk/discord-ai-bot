# Zapier Setup Guide

> **Important:** Zapier does not let you import a Zap from a JSON file the
> way n8n does. `zap-blueprint.json` in this folder is a **reference
> specification** describing exactly what to click — follow the steps below
> to recreate it in a few minutes.

## What this Zap does

Whenever a new row is added to a Google Sheet (e.g. customer feedback),
Zapier calls your Discord AI Bot's `/automation/translate` endpoint and
writes the translated text back into the sheet.

## Step-by-step

| # | Action |
|---|--------|
| 1 | Go to [zapier.com](https://zapier.com) → **Create Zap**. |
| 2 | **Trigger:** search for and select **Google Sheets** → event **New Spreadsheet Row**. Connect your Google account and pick the sheet/worksheet. |
| 3 | **Action 1:** search for **Webhooks by Zapier** → event **POST**. |
| 4 | Set **URL** to `https://YOUR_BOT_HOST/automation/translate` (use an `ngrok` URL for local testing, or your production domain). |
| 5 | Set **Payload Type** to `json`. |
| 6 | Add data fields: `text` → map to the feedback column from Step 1, `target_language` → e.g. `English`. |
| 7 | Under **Headers**, add `Content-Type: application/json` and `X-Webhook-Secret: <your WEBHOOK_SECRET value>`. |
| 8 | **Action 2:** search for **Google Sheets** → event **Update Spreadsheet Row**. Map the `translation` field from Step 4's response into a new column, e.g. `Translated_Text`. |
| 9 | Test each step, then publish the Zap. |

## Example response your bot returns

```json
{
  "translation": "Hola, ¿cómo estás?"
}
```

## Reusing this pattern

Swap the webhook URL for `/automation/summarize`, `/automation/chat`, or
`/automation/moderate` to build summarization, chat, or moderation Zaps
using the same **Webhooks by Zapier → POST** action.
