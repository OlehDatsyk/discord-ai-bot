# Make.com Setup Guide

## What this scenario does

Exposes a Make webhook that forwards an incoming message to your Discord
AI Bot's `/automation/chat` endpoint and responds with the AI's reply -
useful for connecting the bot to a website chat widget, SMS platform, or
any tool that can call a webhook.

## Import steps

| # | Action |
|---|--------|
| 1 | Log into [make.com](https://www.make.com) and open **Scenarios**. |
| 2 | Click **Create a new scenario**, then click the three-dot menu (**...**) in the bottom toolbar → **Import Blueprint**. |
| 3 | Select `discord-ai-bot-scenario.json` from this folder. |
| 4 | Open the **Webhook - Incoming Message** module and click **Add** to generate a live webhook URL; copy it. |
| 5 | Open the **Call Discord AI Bot /automation/chat** module and replace `YOUR_BOT_HOST` with your bot's real address (e.g. an `ngrok` URL for local testing or your production domain). |
| 6 | Under **Headers**, confirm `X-Webhook-Secret` matches the `WEBHOOK_SECRET` value in your bot's `.env`. Since Make does not read your local `.env` file, replace `{{env.WEBHOOK_SECRET}}` with the literal secret value or a Make [Data Store](https://www.make.com/en/help/data-structure) entry. |
| 7 | Save and turn the scenario **ON**. |

## Testing

```bash
curl -X POST https://hook.make.com/your-generated-id \
  -H "Content-Type: application/json" \
  -d '{"message": "What can you help me with?", "user_id": "make-test-user"}'
```

Expected response body: the AI-generated reply text.

## Reusing this pattern

Duplicate module 2 (the HTTP call) and point it at `/automation/summarize`,
`/automation/translate`, or `/automation/moderate` to build other
Make scenarios around the same bot.
